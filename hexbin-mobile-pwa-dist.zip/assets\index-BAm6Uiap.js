var q=Object.defineProperty;var I=(t,e,s)=>e in t?q(t,e,{enumerable:!0,configurable:!0,writable:!0,value:s}):t[e]=s;var $=(t,e,s)=>I(t,typeof e!="symbol"?e+"":e,s);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))r(o);new MutationObserver(o=>{for(const i of o)if(i.type==="childList")for(const d of i.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&r(d)}).observe(document,{childList:!0,subtree:!0});function s(o){const i={};return o.integrity&&(i.integrity=o.integrity),o.referrerPolicy&&(i.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?i.credentials="include":o.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function r(o){if(o.ep)return;o.ep=!0;const i=s(o);fetch(o.href,i)}})();class k{constructor(){$(this,"worker",new Worker(new URL(""+new URL("pyodide.worker-BQAweHqa.js",import.meta.url).href,import.meta.url),{type:"module"}));$(this,"sequence",0);$(this,"pending",new Map);this.worker.onmessage=e=>{const s=e.data,r=this.pending.get(s.id);r&&(this.pending.delete(s.id),s.ok?r.resolve(s.result??"null"):r.reject(new Error(s.error||"核心处理失败。")))}}call(e,...s){const r=++this.sequence;return new Promise((o,i)=>{this.pending.set(r,{resolve:d=>o(JSON.parse(d)),reject:i}),this.worker.postMessage({id:r,method:e,args:s})})}async open(e,s){const r=new Uint8Array(await s.arrayBuffer());let o="";const i=32768;for(let d=0;d<r.length;d+=i)o+=String.fromCharCode(...r.subarray(d,d+i));return this.call("open_file",e,s.name,btoa(o))}readPage(e,s,r){return this.call("read_page",e,s,r)}editByte(e,s,r){return this.call("edit_byte",e,s,r)}search(e,s,r){return this.call("search",e,s,r)}export(e,s){return this.call("export_file",e,s)}}const v=new k,m=1024,x={v50:{metadata:null,page:null,pageStart:0,selectedOffset:null,searchOffset:-1,busy:!1},v11:{metadata:null,page:null,pageStart:0,selectedOffset:null,searchOffset:-1,busy:!1}};let f="v50";const L=document.querySelector("#app");if(!L)throw new Error("页面初始化失败。");L.innerHTML=`
  <header class="topbar">
    <div>
      <p class="eyebrow">文件仅在本机处理 · 支持离线安装</p>
      <h1>固件文件工具箱</h1>
    </div>
    <button class="ghost" id="installButton" hidden>安装到桌面</button>
  </header>
  <main>
    <nav class="tool-tabs" aria-label="工具选择">
      <button class="tool-tab active" data-tool="v50"><strong>主转换工具</strong><span>V50 · 总校验与格式转换</span></button>
      <button class="tool-tab" data-tool="v11"><strong>行校验工具</strong><span>V11 · 单行校验与通用导出</span></button>
    </nav>
    <section id="workspace"></section>
  </main>
  <div id="toast" role="status" aria-live="polite"></div>
`;const C=document.querySelector("#workspace"),E=document.querySelector("#toast");function P(t){return t==="v50"?"主转换工具 V50":"行校验工具 V11"}function j(t){return t==="v50"?".hex,.HEX,.hex_tmp,.s19,.S19,.s28,.S28,.s37,.S37,.mot,.MOT,.srec,.SREC,.bin,.BIN":".hex,.HEX,.bin,.BIN,.s19,.S19,.s28,.S28,.s37,.S37,.mot,.MOT"}function p(t,e=!1){E.textContent=t,E.className=e?"show error":"show",window.setTimeout(()=>{E.className=""},3200)}function c(t,e=8){return`0x${t.toString(16).toUpperCase().padStart(e,"0")}`}function g(){const t=x[f],e=t.metadata;C.innerHTML=`
    <section class="upload-card ${e?"compact":""}">
      <div>
        <p class="section-label">${P(f)}</p>
        <h2>${e?h(e.name):"打开一个固件文件"}</h2>
        <p>${e?`${h(e.format)} · ${h(e.family)}`:"支持 HEX、BIN、S19、S28、S37、MOT 等格式，文件不会上传。"}</p>
      </div>
      <label class="primary ${t.busy?"disabled":""}">
        ${t.busy?"正在载入核心…":e?"更换文件":"选择文件"}
        <input id="fileInput" type="file" accept="${j(f)}" ${t.busy?"disabled":""} />
      </label>
    </section>
    ${e&&t.page?U(t,e):M()}
  `,T()}function M(){return`
    <section class="empty-guide">
      <div><span>1</span><h3>选择文件</h3><p>浏览器直接读取手机或电脑中的文件。</p></div>
      <div><span>2</span><h3>查看与编辑</h3><p>按地址分页，点选字节进行修改。</p></div>
      <div><span>3</span><h3>校验并导出</h3><p>自动重算校验，下载新的文件。</p></div>
    </section>
  `}function U(t,e){const s=t.page,r=t.selectedOffset,o=r===null||r<s.start||r>=s.end?null:s.bytes[r-s.start],i=s.start===0,d=s.end>=s.total,y=[];for(let n=0;n<s.bytes.length;n+=16){const a=s.start+n,l=s.bytes.slice(n,n+16);y.push(`<div class="hex-row"><button class="address" data-jump-offset="${a}">${c(e.baseAddress+a)}</button><div class="byte-row">${l.map((u,S)=>{const b=a+S;return`<button class="byte ${r===b?"selected":""}" data-offset="${b}">${u.toString(16).toUpperCase().padStart(2,"0")}</button>`}).join("")}</div><div class="ascii">${l.map(u=>u>=32&&u<=126?h(String.fromCharCode(u)):".").join("")}</div></div>`)}return`
    <div class="workspace-grid">
      <aside class="info-panel">
        <div class="stat-grid">
          <div><span>起始地址</span><strong>${c(e.baseAddress)}</strong></div>
          <div><span>数据长度</span><strong>${e.size.toLocaleString()} 字节</strong></div>
          <div><span>识别结构</span><strong>${h(e.family)}</strong></div>
          <div><span>校验方式</span><strong>${h(e.checksumScheme)}</strong></div>
        </div>
        <details open><summary>数据段 (${e.segments.length})</summary><div class="detail-list">${e.segments.map((n,a)=>`<p><b>${a+1}</b><span>${c(n.start)} — ${c(n.end)}<small>${n.size.toLocaleString()} 字节</small></span></p>`).join("")}</div></details>
        ${e.checksums.length?`<details open><summary>总校验</summary><div class="checksum-list">${e.checksums.map(n=>`<p><span>段 ${n.segment}</span><code>${n.current||"—"}</code><small>${c(n.start)} — ${c(n.end)}</small></p>`).join("")}</div></details>`:""}
      </aside>
      <section class="editor-panel">
        <div class="controls">
          <form id="jumpForm"><input id="jumpInput" inputmode="text" placeholder="跳转地址，如 2047F0" /><button>跳转</button></form>
          <form id="searchForm"><input id="searchInput" inputmode="text" placeholder="搜索，如 AA 55 01" /><button>搜索</button></form>
        </div>
        <div class="pager"><button id="previousPage" ${i?"disabled":""}>上一页</button><span>${c(e.baseAddress+s.start)} — ${c(e.baseAddress+Math.max(s.start,s.end-1))}</span><button id="nextPage" ${d?"disabled":""}>下一页</button></div>
        <div class="hex-table" aria-label="十六进制编辑器"><div class="hex-header"><span>地址</span><span>00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F</span><span>ASCII</span></div>${y.join("")}</div>
        <div class="edit-bar ${r===null?"disabled":""}">
          <div><span>当前字节</span><strong>${r===null?"未选择":`${c(e.baseAddress+r)} · 偏移 ${c(r)}`}</strong></div>
          <label>十六进制<input id="hexEdit" maxlength="2" inputmode="text" value="${o===null?"":o.toString(16).toUpperCase().padStart(2,"0")}" ${r===null?"disabled":""} /></label>
          <label>字符<input id="asciiEdit" maxlength="1" value="${o!==null&&o>=32&&o<=126?h(String.fromCharCode(o)):""}" ${r===null?"disabled":""} /></label>
          <button id="applyEdit" class="primary" ${r===null?"disabled":""}>应用修改</button>
        </div>
        <div class="export-bar"><span>导出后会自动应用镜像和校验规则</span><div>${B(f)}</div></div>
      </section>
    </div>
  `}function B(t){return(t==="v50"?["hex","bin"]:["hex","bin","s19","mot","s28","s37"]).map(s=>`<button class="export" data-format="${s}">导出 ${s.toUpperCase()}</button>`).join("")}function h(t){return t.replace(/[&<>'"]/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"})[e])}async function w(t,e){const s=x[t];s.metadata&&(s.pageStart=Math.max(0,Math.floor(e/16)*16),s.page=await v.readPage(s.metadata.sessionId,s.pageStart,m),g())}function N(t,e){const s=t.trim().replace(/[_\s]/g,"").replace(/^0x/i,"");if(!/^[0-9a-f]+$/i.test(s))throw new Error("请输入有效的十六进制地址。 ");const r=Number.parseInt(s,16);if(r>=e.baseAddress&&r<e.baseAddress+e.size)return r-e.baseAddress;if(r>=0&&r<e.size)return r;throw new Error(`地址范围是 ${c(e.baseAddress)} 到 ${c(e.baseAddress+e.size-1)}。`)}function T(){var e,s,r,o,i,d,y;const t=x[f];(e=document.querySelector("#fileInput"))==null||e.addEventListener("change",async n=>{var l;const a=(l=n.currentTarget.files)==null?void 0:l[0];if(a){t.busy=!0,g();try{t.metadata=await v.open(f,a),t.pageStart=0,t.selectedOffset=null,t.searchOffset=-1,t.page=await v.readPage(t.metadata.sessionId,0,m),p("文件已打开，核心算法在本机运行。 ")}catch(u){t.metadata=null,t.page=null,p(u instanceof Error?u.message:String(u),!0)}finally{t.busy=!1,g()}}}),document.querySelectorAll(".byte").forEach(n=>n.addEventListener("click",()=>{var a;t.selectedOffset=Number(n.dataset.offset),g(),(a=document.querySelector("#hexEdit"))==null||a.focus()})),(s=document.querySelector("#previousPage"))==null||s.addEventListener("click",()=>void w(f,t.pageStart-m)),(r=document.querySelector("#nextPage"))==null||r.addEventListener("click",()=>void w(f,t.pageStart+m)),(o=document.querySelector("#jumpForm"))==null||o.addEventListener("submit",n=>{if(n.preventDefault(),!!t.metadata)try{const a=N(document.querySelector("#jumpInput").value,t.metadata);t.selectedOffset=a,w(f,Math.floor(a/m)*m)}catch(a){p(a instanceof Error?a.message:String(a),!0)}}),(i=document.querySelector("#searchForm"))==null||i.addEventListener("submit",async n=>{if(n.preventDefault(),!!t.metadata)try{const a=document.querySelector("#searchInput").value,l=await v.search(t.metadata.sessionId,a,t.searchOffset+1);if(l.offset<0)return p("没有找到该内容。 ",!0);t.searchOffset=l.offset,t.selectedOffset=l.offset,await w(f,Math.floor(l.offset/m)*m),p(`已找到 ${c(t.metadata.baseAddress+l.offset)}。`)}catch(a){p(a instanceof Error?a.message:String(a),!0)}}),(d=document.querySelector("#applyEdit"))==null||d.addEventListener("click",async()=>{if(!t.metadata||t.selectedOffset===null)return;const n=document.querySelector("#hexEdit");if(!/^[0-9a-f]{2}$/i.test(n.value))return p("十六进制值必须是两位，例如 0A。",!0);try{const a=await v.editByte(t.metadata.sessionId,t.selectedOffset,Number.parseInt(n.value,16));t.metadata={...a.metadata,sessionId:t.metadata.sessionId},t.page=await v.readPage(t.metadata.sessionId,t.pageStart,m),g(),p("修改成功，相关校验已自动更新。 ")}catch(a){p(a instanceof Error?a.message:String(a),!0)}}),(y=document.querySelector("#asciiEdit"))==null||y.addEventListener("input",n=>{const a=n.currentTarget.value;a&&(document.querySelector("#hexEdit").value=a.charCodeAt(0).toString(16).toUpperCase().padStart(2,"0"))}),document.querySelectorAll(".export").forEach(n=>n.addEventListener("click",async()=>{if(t.metadata){n.disabled=!0;try{const a=await v.export(t.metadata.sessionId,n.dataset.format),l=atob(a.payload),u=Uint8Array.from(l,O=>O.charCodeAt(0)),S=URL.createObjectURL(new Blob([u],{type:a.mime})),b=document.createElement("a");b.href=S,b.download=a.name,b.click(),URL.revokeObjectURL(S),p(`已生成 ${a.name}。`)}catch(a){p(a instanceof Error?a.message:String(a),!0)}finally{n.disabled=!1}}}))}document.querySelectorAll(".tool-tab").forEach(t=>t.addEventListener("click",()=>{f=t.dataset.tool,document.querySelectorAll(".tool-tab").forEach(e=>e.classList.toggle("active",e===t)),g()}));let A=null;window.addEventListener("beforeinstallprompt",t=>{t.preventDefault(),A=t;const e=document.querySelector("#installButton");e.hidden=!1,e.onclick=()=>A.prompt()});"serviceWorker"in navigator&&window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js"));g();
